package com.nistagram.proxyserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
